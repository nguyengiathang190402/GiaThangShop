<div class="hot-products">
    <h3 class="title">Giới Thiệu</h3>
    <div class="control"><a id="prev_hot" class="prev" href="#">&lt;</a><a id="next_hot" class="next" href="#">&gt;</a></div>
                 
    </div>