<div class="clearfix"></div>
         <div class="footer">
            <div class="footer-info">
               <div class="container">
                  <div class="row">
                     <div class="col-md-3">
                        <div class="footer-logo"><a href="#"><img src="view/images/logo2.png" alt=""></a></div>
                     </div>
                     <div class="col-md-3 col-sm-6">
                        <h4 class="title">Thông tin <strong>liên hệ </strong></h4>
                        <p>324, Phương Canh, Hà Nội , Việt Nam</p>
                        <p>Số điện thoại : 0123456789</p>
                        <p>Email : thangngph13947@fpt.edu.vn</p>
                     </div>
                     <div class="col-md-3 col-sm-6">
                        <h4 class="title">Hỗ trợ <strong> khách hàng</strong></h4>
                        <ul class="support">
                           <li><a href="#">Câu hỏi thường gặp</a></li>
                           <li><a href="#">Phương thức thanh toán</a></li>
                           <li><a href="#">Mẹo đặt hàng</a></li>
                           <li><a href="#">Thông tin</a></li>
                        </ul>
                     </div>
                     <div class="col-md-3">
                        <h4 class="title">Nhận bản tin của <strong> chúng tôi</strong></h4>
                        <p><strong>Hãy đến với chúng tôi để tìm được sự khác biệt. </strong></p>
                        <form class="newsletter">
							<input type="text" name="" placeholder="Nhập email của bạn">
							<input type="submit" value="Đăng ký" class="button">
						</form>
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyright-info">
               <div class="container">
                  <div class="row">
                     <div class="col-md-6">
                        <p>Copyright © 2021. Designed by <a href="#">Nguyễn Gia Thắng</a>. All rights reseved</p>
                     </div>
                     <div class="col-md-6">
                        <ul class="social-icon">
                           <li><a href="#" class="linkedin"></a></li>
                           <li><a href="#" class="google-plus"></a></li>
                           <li><a href="#" class="twitter"></a></li>
                           <li><a href="#" class="facebook"></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- Bootstrap core JavaScript==================================================-->
	  <script type="text/javascript" src="view/js/jquery-1.10.2.min.js"></script>
	  <script type="text/javascript" src="view/js/jquery.easing.1.3.js"></script>
	  <script type="text/javascript" src="view/js/bootstrap.min.js"></script>
	  <script type="text/javascript" src="view/js/jquery.sequence-min.js"></script>
	  <script type="text/javascript" src="view/js/jquery.carouFredSel-6.2.1-packed.js"></script>
	  <script defer src="view/js/jquery.flexslider.js"></script>
	  <script type="text/javascript" src="view/js/script.min.js" ></script>
   </body>
</html>